﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase3WilsonCastro
{
    internal class EstructurasDatosUsuarios
    {
        public string strTipodeIdentificacion { get; set; }
        public string strNrodeIdentificacion { get; set; }
        public string strNombreCompleto { get; set; }
        public string strEdad { get; set; }
        public string strEstratoSocioeconomico { get; set; }
        public string strTipodeAtencion { get; set; }
        public int intValordeCopago { get; set; }
        public string strFechadeAcceso { get; set; }
        
    }
}
